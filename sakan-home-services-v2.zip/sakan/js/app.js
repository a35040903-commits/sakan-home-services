(function () {
  "use strict";

  /* ---------------------------------------------------------
     Helpers
     --------------------------------------------------------- */
  function fmtPrice(n) {
    return n.toFixed(3) + " ر.ع";
  }
  function toast(msg) {
    var el = document.getElementById("toast");
    el.textContent = msg;
    el.classList.add("is-visible");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () {
      el.classList.remove("is-visible");
    }, 2600);
  }
  function todayISO() {
    var d = new Date();
    return d.toISOString().slice(0, 10);
  }
  function tomorrowISO() {
    var d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  }
  function packageById(id) {
    return PRICING.packages.find(function (p) { return p.id === id; });
  }

  /* ---------------------------------------------------------
     Header: scroll state + mobile nav
     --------------------------------------------------------- */
  var header = document.getElementById("siteHeader");
  window.addEventListener("scroll", function () {
    header.classList.toggle("is-scrolled", window.scrollY > 8);
  }, { passive: true });

  var navToggle = document.getElementById("navToggle");
  var mainNav = document.getElementById("mainNav");
  navToggle.addEventListener("click", function () {
    var open = mainNav.classList.toggle("is-open");
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
  });
  mainNav.querySelectorAll("a").forEach(function (a) {
    a.addEventListener("click", function () {
      mainNav.classList.remove("is-open");
      navToggle.setAttribute("aria-expanded", "false");
    });
  });

  /* ---------------------------------------------------------
     Hero slider (auto-rotating, manual controls, no dependencies)
     --------------------------------------------------------- */
  (function initHeroSlider() {
    var stage = document.getElementById("heroStage");
    if (!stage) return;
    var slides = Array.prototype.slice.call(stage.querySelectorAll(".hero-slide"));
    var dots = Array.prototype.slice.call(stage.querySelectorAll(".hero-dot"));
    var prevBtn = document.getElementById("heroPrev");
    var nextBtn = document.getElementById("heroNext");
    if (!slides.length) return;

    var index = 0;
    var AUTOPLAY_MS = 5000;
    var timer = null;

    function show(i) {
      index = (i + slides.length) % slides.length;
      slides.forEach(function (s, si) { s.classList.toggle("is-active", si === index); });
      dots.forEach(function (d, di) { d.classList.toggle("is-active", di === index); });
    }

    function next() { show(index + 1); }
    function prev() { show(index - 1); }

    function startAutoplay() {
      stopAutoplay();
      timer = setInterval(next, AUTOPLAY_MS);
    }
    function stopAutoplay() {
      if (timer) clearInterval(timer);
    }
    function restartAutoplay() {
      startAutoplay();
    }

    dots.forEach(function (d) {
      d.addEventListener("click", function () {
        show(parseInt(d.dataset.slide, 10));
        restartAutoplay();
      });
    });
    if (nextBtn) nextBtn.addEventListener("click", function () { next(); restartAutoplay(); });
    if (prevBtn) prevBtn.addEventListener("click", function () { prev(); restartAutoplay(); });

    stage.addEventListener("mouseenter", stopAutoplay);
    stage.addEventListener("mouseleave", startAutoplay);
    stage.addEventListener("focusin", stopAutoplay);
    stage.addEventListener("focusout", startAutoplay);

    show(0);
    startAutoplay();
  })();

  /* ---------------------------------------------------------
     Workers grid: render + filter + sort
     --------------------------------------------------------- */
  var grid = document.getElementById("workersGrid");
  var filtersBar = document.getElementById("filters");
  var state = { filter: "all", sort: null };

  function starIcon() {
    return '<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.7 7-6.3-3.8L5.7 21l1.7-7-5.4-4.7 7.1-.6z"/></svg>';
  }

  function workerCardHTML(w) {
    var badgeClass = w.availability === "today" ? "today" : "tomorrow";
    var startPkg = PRICING.packages[0];
    return (
      '<article class="worker-card" data-id="' + w.id + '">' +
        '<div class="worker-media">' +
          '<img src="' + w.avatar + '" alt="صورة مزودة الخدمة ' + w.name + '" loading="lazy">' +
          '<span class="worker-badge ' + badgeClass + '">' + w.availabilityLabel + '</span>' +
          '<span class="worker-rating">' + starIcon() + ' ' + w.rating.toFixed(1) + '</span>' +
        '</div>' +
        '<div class="worker-body">' +
          '<div class="worker-name-row"><h3>' + w.name + '</h3><span class="worker-nat">' + w.nationality + '</span></div>' +
          '<div class="worker-meta"><span>' + w.experience + ' سنوات خبرة</span></div>' +
          '<p class="worker-services"><strong>الخدمات: </strong>' + w.services.join('، ') + '</p>' +
          '<div class="worker-price-block">' +
            '<span class="worker-price-from">يبدأ من</span>' +
            '<strong class="worker-price-amt">' + startPkg.price.toFixed(3) + ' ر.ع</strong>' +
            '<span class="worker-price-unit">/ ' + startPkg.label + '</span>' +
          '</div>' +
          '<p class="worker-price-hint">خيارات 4، 6، 8 ساعات أو يوم كامل</p>' +
          '<div class="worker-actions">' +
            '<button class="btn btn-ghost btn-sm" data-action="details" data-id="' + w.id + '">عرض التفاصيل</button>' +
            '<button class="btn btn-primary btn-sm" data-action="book" data-id="' + w.id + '">احجز الآن</button>' +
          '</div>' +
        '</div>' +
      '</article>'
    );
  }

  function renderGrid() {
    var list = WORKERS.slice();

    if (state.filter === "today") {
      list = list.filter(function (w) { return w.availability === "today"; });
    }
    if (state.sort === "rating") {
      list.sort(function (a, b) { return b.rating - a.rating; });
    } else if (state.sort === "experience") {
      list.sort(function (a, b) { return b.experience - a.experience; });
    }

    if (!list.length) {
      grid.innerHTML = '<div class="empty-state">لا توجد عاملات مطابقة لهذا الفلتر حاليًا.</div>';
      return;
    }
    grid.innerHTML = list.map(workerCardHTML).join("");
  }

  filtersBar.addEventListener("click", function (e) {
    var btn = e.target.closest(".filter-chip");
    if (!btn) return;

    if (btn.dataset.filter) {
      state.filter = btn.dataset.filter;
      filtersBar.querySelectorAll("[data-filter]").forEach(function (b) {
        b.classList.toggle("is-active", b === btn);
      });
      if (btn.dataset.filter === "all") {
        filtersBar.querySelectorAll("[data-sort]").forEach(function (b) { b.classList.remove("is-active"); });
      }
    } else if (btn.dataset.sort) {
      var already = btn.classList.contains("is-active");
      filtersBar.querySelectorAll("[data-sort]").forEach(function (b) { b.classList.remove("is-active"); });
      state.sort = already ? null : btn.dataset.sort;
      if (!already) btn.classList.add("is-active");
    }
    renderGrid();
  });

  grid.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-action]");
    if (!btn) return;
    var worker = WORKERS.find(function (w) { return w.id === btn.dataset.id; });
    if (!worker) return;
    openModal(worker, btn.dataset.action === "book");
  });

  renderGrid();

  /* ---------------------------------------------------------
     Search bar (home hero)
     --------------------------------------------------------- */
  var searchBar = document.getElementById("searchBar");
  searchBar.addEventListener("submit", function (e) {
    e.preventDefault();
    var service = document.getElementById("searchService").value;
    var duration = document.getElementById("searchDuration").value;

    document.getElementById("workers").scrollIntoView({ behavior: "smooth" });

    if (service) {
      toast('نعرض لك مزودات خدمة "' + service + '"');
    } else {
      toast("هذه هي مزودات الخدمة المتاحات حاليًا");
    }
    // service/duration are informational in this demo; grid already shows all providers with full details.
    void duration;
  });

  /* ---------------------------------------------------------
     Modal: details + booking
     --------------------------------------------------------- */
  var overlay = document.getElementById("modalOverlay");
  var modalBody = document.getElementById("modalBody");
  var modalClose = document.getElementById("modalClose");

  var bookingState = null; // per-open booking state

  function closeModal() {
    overlay.classList.remove("is-open");
    document.body.style.overflow = "";
  }
  modalClose.addEventListener("click", closeModal);
  overlay.addEventListener("click", function (e) {
    if (e.target === overlay) closeModal();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && overlay.classList.contains("is-open")) closeModal();
  });

  function openModal(worker, jumpToBooking) {
    bookingState = {
      worker: worker,
      packageId: "h4",
      date: worker.availability === "today" ? todayISO() : tomorrowISO(),
      time: worker.slots[0]
    };
    modalBody.innerHTML = detailHTML(worker);
    wireModal();
    overlay.classList.add("is-open");
    document.body.style.overflow = "hidden";
    if (jumpToBooking) {
      var bookingEl = modalBody.querySelector("#bookingSection");
      if (bookingEl) setTimeout(function () { bookingEl.scrollIntoView({ block: "start" }); }, 50);
    } else {
      modalBody.scrollTop = 0;
    }
  }

  function packageOptionHTML(pkg, isActive) {
    return (
      '<button type="button" class="package-option' + (isActive ? " is-active" : "") + '" data-package="' + pkg.id + '">' +
        '<span class="package-label">' + pkg.label + '</span>' +
        '<span class="package-price">' + fmtPrice(pkg.price) + '</span>' +
      '</button>'
    );
  }

  function detailHTML(w) {
    var badgeClass = w.availability === "today" ? "today" : "tomorrow";
    var firstPkg = packageById(bookingState.packageId);
    return (
      '<div class="detail-head">' +
        '<div class="detail-avatar"><img src="' + w.avatar + '" alt="صورة مزودة الخدمة ' + w.name + '"></div>' +
        '<div>' +
          '<h2 id="modalWorkerName">' + w.name + '</h2>' +
          '<p class="detail-sub">' + w.nationality + ' · ' + w.experience + ' سنوات خبرة</p>' +
        '</div>' +
      '</div>' +

      '<div class="detail-badges">' +
        '<span class="worker-badge ' + badgeClass + '" style="border:none">' + w.availabilityLabel + '</span>' +
        '<span>' + starIcon() + ' ' + w.rating.toFixed(1) + ' تقييم</span>' +
        '<span>اللغات: ' + w.languages.join('، ') + '</span>' +
      '</div>' +

      '<p class="worker-services"><strong>الخدمات: </strong>' + w.services.join('، ') + '</p>' +
      '<p class="worker-services"><strong>الأوقات المتاحة: </strong>' + w.slots.join('، ') + '</p>' +

      '<div id="bookingSection">' +
        '<h3 class="detail-section-title">اختر مدة الخدمة</h3>' +
        '<div class="package-grid" id="packageGrid">' +
          PRICING.packages.map(function (p) { return packageOptionHTML(p, p.id === bookingState.packageId); }).join("") +
        '</div>' +
        '<p class="package-note">الحد الأدنى للحجز 4 ساعات — لا يمكن اختيار مدة أقل.</p>' +

        '<div class="field-row two">' +
          '<div class="field">' +
            '<label for="bookService">نوع الخدمة</label>' +
            '<select id="bookService">' + w.services.map(function (s) { return '<option value="' + s + '">' + s + '</option>'; }).join("") + '</select>' +
          '</div>' +
          '<div class="field"></div>' +
        '</div>' +

        '<div class="field-row two">' +
          '<div class="field">' +
            '<label for="bookDate">التاريخ</label>' +
            '<input type="date" id="bookDate" min="' + todayISO() + '" value="' + bookingState.date + '">' +
          '</div>' +
          '<div class="field">' +
            '<label for="bookTime">الوقت</label>' +
            '<select id="bookTime">' + w.slots.map(function (s) { return '<option value="' + s + '">' + s + '</option>'; }).join("") + '</select>' +
          '</div>' +
        '</div>' +

        '<div class="price-line" style="margin-top:16px">' +
          '<span>الإجمالي</span>' +
          '<strong id="totalPrice">' + fmtPrice(firstPkg.price) + '</strong>' +
        '</div>' +

        '<h3 class="detail-section-title">بيانات العميل</h3>' +
        '<div class="booking-fields">' +
          '<div class="field-row two">' +
            '<div class="field"><label for="custName">الاسم</label><input type="text" id="custName" placeholder="اسمك الكامل"></div>' +
            '<div class="field"><label for="custPhone">رقم الهاتف</label><input type="tel" id="custPhone" placeholder="9xxxxxxx"></div>' +
          '</div>' +
          '<div class="field-row two">' +
            '<div class="field"><label for="custArea">المنطقة</label><input type="text" id="custArea" placeholder="مثال: الخوض"></div>' +
            '<div class="field"><label for="custState">الولاية</label><input type="text" id="custState" placeholder="مثال: السيب"></div>' +
          '</div>' +
          '<div class="field"><label for="custAddress">العنوان</label><input type="text" id="custAddress" placeholder="أقرب معلم / رقم المنزل"></div>' +
          '<div class="field"><label for="custNotes">ملاحظات (اختياري)</label><textarea id="custNotes" rows="2" placeholder="أي تفاصيل إضافية تودّ إخبارنا بها"></textarea></div>' +
        '</div>' +
        '<p class="field-error" id="formError" style="display:none"></p>' +

        '<h3 class="detail-section-title">ملخص الحجز</h3>' +
        '<div class="summary-box" id="summaryBox"></div>' +

        '<button type="button" class="btn btn-primary btn-block btn-lg" id="confirmBtn">تأكيد الحجز</button>' +
        '<p class="form-note">عند التأكيد سيتم فتح واتساب برسالة تحتوي تفاصيل حجزك لإتمامه مع فريق سكن. هذه نسخة تجريبية ولا يتم خصم أي مبلغ فعلي.</p>' +
      '</div>'
    );
  }

  function wireModal() {
    var w = bookingState.worker;
    var packageGrid = modalBody.querySelector("#packageGrid");
    var totalPrice = modalBody.querySelector("#totalPrice");
    var bookService = modalBody.querySelector("#bookService");
    var bookDate = modalBody.querySelector("#bookDate");
    var bookTime = modalBody.querySelector("#bookTime");
    var summaryBox = modalBody.querySelector("#summaryBox");
    var confirmBtn = modalBody.querySelector("#confirmBtn");
    var formError = modalBody.querySelector("#formError");

    function currentPackage() {
      return packageById(bookingState.packageId);
    }

    function updatePrice() {
      var pkg = currentPackage();
      bookingState.total = pkg.price;
      totalPrice.textContent = fmtPrice(pkg.price);
      updateSummary();
    }

    function updateSummary() {
      var pkg = currentPackage();
      summaryBox.innerHTML =
        '<div class="summary-row"><span>العاملة</span><span>' + w.name + '</span></div>' +
        '<div class="summary-row"><span>الخدمة</span><span>' + (bookService.value || w.services[0]) + '</span></div>' +
        '<div class="summary-row"><span>مدة الحجز</span><span>' + pkg.label + '</span></div>' +
        '<div class="summary-row"><span>التاريخ</span><span>' + (bookDate.value || "—") + '</span></div>' +
        '<div class="summary-row"><span>الوقت</span><span>' + (bookTime.value || "—") + '</span></div>' +
        '<div class="summary-row total"><span>السعر النهائي</span><span>' + fmtPrice(pkg.price) + '</span></div>';
    }

    packageGrid.addEventListener("click", function (e) {
      var btn = e.target.closest(".package-option");
      if (!btn) return;
      bookingState.packageId = btn.dataset.package;
      packageGrid.querySelectorAll(".package-option").forEach(function (b) {
        b.classList.toggle("is-active", b === btn);
      });
      updatePrice();
    });

    bookService.addEventListener("change", updateSummary);
    bookDate.addEventListener("change", updateSummary);
    bookTime.addEventListener("change", updateSummary);

    confirmBtn.addEventListener("click", function () {
      var name = modalBody.querySelector("#custName").value.trim();
      var phone = modalBody.querySelector("#custPhone").value.trim();
      var area = modalBody.querySelector("#custArea").value.trim();
      var stateVal = modalBody.querySelector("#custState").value.trim();
      var address = modalBody.querySelector("#custAddress").value.trim();
      var notes = modalBody.querySelector("#custNotes").value.trim();

      if (!name || !phone || !area || !stateVal || !address) {
        formError.style.display = "block";
        formError.textContent = "الرجاء تعبئة الاسم ورقم الهاتف والمنطقة والولاية والعنوان لإتمام الحجز.";
        return;
      }
      formError.style.display = "none";

      var pkg = currentPackage();
      var lines = [
        "طلب حجز جديد عبر سكن",
        "—",
        "اسم العميل: " + name,
        "رقم الهاتف: " + phone,
        "—",
        "العاملة: " + w.name + " (" + w.nationality + ")",
        "الخدمة: " + (bookService.value || w.services[0]),
        "مدة الحجز: " + pkg.label,
        "التاريخ: " + (bookDate.value || "—"),
        "الوقت: " + (bookTime.value || "—"),
        "المنطقة: " + area,
        "الولاية: " + stateVal,
        "العنوان: " + address,
        "السعر النهائي: " + fmtPrice(pkg.price)
      ];
      if (notes) lines.push("ملاحظات: " + notes);

      var message = encodeURIComponent(lines.join("\n"));
      var url = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + message;
      window.open(url, "_blank", "noopener");
      toast("جاري فتح واتساب لتأكيد حجزك");
    });

    updatePrice();
  }

})();
