// بيانات تجريبية (Demo) فقط — لا تمثل أشخاصًا حقيقيين

// نظام تسعير الباقات — قيم ثابتة سهلة التعديل (لا يوجد ضرب بالساعة)
const PRICING = {
  packages: [
    { id: "h4", label: "4 ساعات", hours: 4, price: 6 },
    { id: "h6", label: "6 ساعات", hours: 6, price: 9 },
    { id: "h8", label: "8 ساعات", hours: 8, price: 12 },
    { id: "day", label: "يوم كامل", hours: null, price: 15 }
  ]
};

const WORKERS = [
  {
    id: "maria",
    name: "Maria",
    nationality: "الفلبين",
    experience: 5,
    rating: 4.9,
    services: ["تنظيف المنزل", "كي الملابس"],
    availability: "today",
    availabilityLabel: "متاحة اليوم",
    languages: ["العربية", "الإنجليزية"],
    avatar: "images/maria.jpg",
    slots: ["09:00 ص", "11:00 ص", "02:00 م", "04:00 م"]
  },
  {
    id: "lina",
    name: "Lina",
    nationality: "إندونيسيا",
    experience: 6,
    rating: 4.9,
    services: ["تنظيف المنزل", "كي الملابس", "ترتيب المنزل"],
    availability: "tomorrow",
    availabilityLabel: "متاحة غدًا",
    languages: ["العربية", "الإندونيسية"],
    avatar: "images/lina.jpg",
    slots: ["09:00 ص", "12:00 م", "03:00 م"]
  },
  {
    id: "maya",
    name: "Maya",
    nationality: "كينيا",
    experience: 3,
    rating: 4.7,
    services: ["تنظيف المنزل"],
    availability: "today",
    availabilityLabel: "متاحة اليوم",
    languages: ["الإنجليزية", "السواحيلية"],
    avatar: "images/maya.jpg",
    slots: ["08:00 ص", "10:00 ص", "01:00 م"]
  },
  {
    id: "sara",
    name: "Sara",
    nationality: "سريلانكا",
    experience: 7,
    rating: 4.9,
    services: ["تنظيف عميق"],
    availability: "today",
    availabilityLabel: "متاحة اليوم",
    languages: ["الإنجليزية"],
    avatar: "images/sara.jpg",
    slots: ["09:00 ص", "12:00 م", "03:00 م", "06:00 م"]
  },
  {
    id: "anna",
    name: "Anna",
    nationality: "أوغندا",
    experience: 4,
    rating: 4.8,
    services: ["تنظيف عميق"],
    availability: "today",
    availabilityLabel: "متاحة اليوم",
    languages: ["الإنجليزية"],
    avatar: "images/anna.jpg",
    slots: ["10:00 ص", "01:00 م", "05:00 م"]
  },
  {
    id: "nina",
    name: "Nina",
    nationality: "الفلبين",
    experience: 8,
    rating: 5.0,
    services: ["تنظيف احترافي", "كي الملابس", "ترتيب المنزل"],
    availability: "tomorrow",
    availabilityLabel: "متاحة غدًا",
    languages: ["العربية", "الإنجليزية"],
    avatar: "images/nina.jpg",
    slots: ["08:00 ص", "11:00 ص", "02:00 م", "04:00 م"]
  }
];

// صور Hero Slider
const HERO_SLIDES = ["images/hero-01.jpg", "images/hero-02.jpg", "images/hero-03.jpg"];

// رقم واتساب تجريبي لأغراض العرض فقط
const WHATSAPP_NUMBER = "96890000000";
